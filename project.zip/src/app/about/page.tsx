import AboutCompany from "@/components/AboutCompany";
import BackToTop from "@/components/BackToTop";
import BreadCrum2 from "@/components/BreadCrum2";
import Features from "@/components/Features";
import Footer from "@/components/Footer";
import FooterTopCTA from "@/components/FooterTopCTA";
import Navbar from "@/components/Navbar/Navbar";
import StickyNavbar from "@/components/StickyNavbar";
import React from "react";

const page = () => {
  return (
    <>
      <Navbar />
      <StickyNavbar />
      <BreadCrum2 breadcrumbItems={[]} pageTitle={"About Us"} imageSrc={"/slider-1.jpg"} />
      <AboutCompany />
      <Features />
      <FooterTopCTA />
      <Footer />
      <BackToTop />
    </>
  );
};

export default page;
